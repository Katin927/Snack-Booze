### Conceptual Exercise

Answer the following questions below:

1. **What is the purpose of the React Router?**  
   React Router allows for navigation between different components in a React application without reloading the entire page. It helps create dynamic, single-page applications (SPAs) by mapping URLs to specific components.

2. **What is a single-page application (SPA)?**  
   An SPA loads a single HTML page and dynamically updates the page content as the user interacts with the app, offering a faster and smoother user experience.

3. **What are the differences between client-side and server-side routing?**  
   - *Client-side routing:* Handles navigation within the browser, avoiding full page reloads and enabling faster transitions.  
   - *Server-side routing:* Each route change triggers a request to the server, resulting in a full page reload. It is generally better for SEO but can be slower.

4. **What are two ways to handle redirects with React Router?**  
   - Using `<Navigate to="/path" />` in component rendering for automatic redirects.  
   - Using the `useNavigate()` hook to programmatically redirect within a function or event.

5. **What are two methods to handle 404 (Page Not Found) experiences in React Router?**  
   - Adding a wildcard route (`<Route path="*" element={<NotFound />} />`) to display a custom 404 page.  
   - Using `<Navigate to="/404" />` to redirect to a dedicated 404 route.

6. **How do you access URL parameters in a component using React Router?**  
   - `useParams()` hook to access dynamic segments from the URL (e.g., `/user/:id`).  
   - `useLocation()` hook to get the full URL or query parameters (`?key=value`).

7. **What is context in React and when should you use it?**  
   React Context provides a way to share data (like themes, authentication) globally across components without passing props through every level.

8. **What are the differences between class-based components and function components in React?**  
   - *Class-based components:* Use lifecycle methods (`componentDidMount`) and `this.state`.  
   - *Function components:* Use hooks (`useState`, `useEffect`), providing a simpler and more modern approach to building components.

9. **What problems do React hooks solve?**  
   - Simplify state management with `useState`.  
   - Manage side effects using `useEffect`.  
   - Avoid complex class components and enable cleaner, reusable code through custom hooks.


Unroll
function unroll(square) {
    let result = [];
    let n = square.length;
    let top = 0, bottom = n - 1, left = 0, right = n - 1;

    while (top <= bottom && left <= right) {
        // Traverse from left to right
        for (let i = left; i <= right; i++) {
            result.push(square[top][i]);
        }
        top++;

        // Traverse downwards
        for (let i = top; i <= bottom; i++) {
            result.push(square[i][right]);
        }
        right--;

        if (top <= bottom) {
            // Traverse from right to left
            for (let i = right; i >= left; i--) {
                result.push(square[bottom][i]);
            }
            bottom--;
        }

        if (left <= right) {
            // Traverse upwards
            for (let i = bottom; i >= top; i--) {
                result.push(square[i][left]);
            }
            left++;
        }
    }

    return result;
}

input
const square = [
  [1, 2, 3, 4],
  [5, 6, 7, 8],
  [9, 10, 11, 12],
  [13, 14, 15, 16]
];

Calling unroll(square) will return:
[1, 2, 3, 4, 8, 12, 16, 15, 14, 13, 9, 5, 6, 7, 11, 10]

For the input:
const smallerSquare = [
  ["a", "b", "c"],
  ["d", "e", "f"],
  ["g", "h", "i"]
];

Calling unroll(smallerSquare) will return:
["a", "b", "c", "f", "i", "h", "g", "d", "e"]
