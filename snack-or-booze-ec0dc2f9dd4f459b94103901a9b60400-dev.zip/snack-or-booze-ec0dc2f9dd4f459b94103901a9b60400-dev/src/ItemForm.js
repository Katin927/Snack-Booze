// src/ItemForm.js
import React, { useState } from 'react';

const ItemForm = ({ onAddItem }) => {
  const [itemName, setItemName] = useState('');
  const [itemDescription, setItemDescription] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    // Logic to handle form submission
    if (itemName && itemDescription) {
      onAddItem({ name: itemName, description: itemDescription });
      setItemName('');
      setItemDescription('');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="Item Name"
        value={itemName}
        onChange={(e) => setItemName(e.target.value)}
        required
      />
      <input
        type="text"
        placeholder="Item Description"
        value={itemDescription}
        onChange={(e) => setItemDescription(e.target.value)}
        required
      />
      <button type="submit">Add Item</button>
    </form>
  );
};

export default ItemForm;
