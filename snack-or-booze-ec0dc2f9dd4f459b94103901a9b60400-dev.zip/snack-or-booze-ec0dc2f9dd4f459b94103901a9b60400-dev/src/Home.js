import React from 'react';
import { Card, CardBody, CardTitle } from 'reactstrap';

/** Displays homepage.
 * 
 * -Displays the number of snacks and drinks
 * -Displays navbar.
 *
 */

function Home({ snacks, drinks }) {
	return (
		<section className="col-md-8">
			<Card>
				<CardBody className="text-center">
					<CardTitle>
						<h3 className="font-weight-bold">Welcome to SoBro's Cafe!</h3>
						<p>
						{snacks.length} Tasty snacks to satisfy your cravings.
						<p></p>
						{drinks.length} Refreshing drinks to quench your thirst.
						<p></p> 
						Come for the food, stay for the vibe! 
						</p>
					</CardTitle>
				</CardBody>
			</Card>
		</section>
	);
}

export default Home;