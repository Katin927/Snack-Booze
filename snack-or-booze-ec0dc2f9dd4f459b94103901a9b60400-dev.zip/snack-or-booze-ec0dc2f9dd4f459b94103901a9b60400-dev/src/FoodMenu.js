import React from 'react';
import { Link } from 'react-router-dom';

const FoodMenu = ({ items, title }) => {
  return (
    <div className="main-menu">
      <h2>{title}</h2>
      <ul className="list-group">
        {items.length === 0 ? (
          <li>No items available</li>
        ) : (
          items.map(item => (
            <li key={item.id} className="list-group-item">
              <Link to={`/${title.toLowerCase()}/${item.id}`} className="menu-link">
                {item.name}
              </Link>
              <p>{item.description}</p>
            </li>
          ))
        )}
      </ul>
    </div>
  );
};

export default FoodMenu;
