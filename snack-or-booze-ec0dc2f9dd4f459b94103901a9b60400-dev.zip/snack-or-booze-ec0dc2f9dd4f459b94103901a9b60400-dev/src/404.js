import React from 'react';
import { Link } from 'react-router-dom';
import './404.css'; // Import the CSS file

const NotFound = () => {
  return (
    <div className="not-found-container">
      <h1>404 - Page Not Found</h1>
      <p>The page you are looking for doesn't exist.</p>
      <p>
        You can go back to the <Link to="/">Home Page</Link> or try another route.
      </p>
    </div>
  );
};

export default NotFound;
