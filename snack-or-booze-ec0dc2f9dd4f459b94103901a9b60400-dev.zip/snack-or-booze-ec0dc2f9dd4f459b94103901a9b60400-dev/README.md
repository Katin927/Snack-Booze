# Snack or Booze

- View the rubric for this assessment [here](https://storage.googleapis.com/hatchways.appspot.com/employers/springboard/student_rubrics/Snack%20or%20Booze%20-%20Student%20Guide.pdf)
